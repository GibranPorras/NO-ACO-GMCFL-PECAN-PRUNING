function Valores_verdad = calcular_objetivos(OrderArray, branches_height, azimuths, lai_info, ramas_finas, cant_finas,branches_angle, volumen_tree, volumen_tree_original, l1, b1, l2, b2, l3, b3, l4, b4, l6, b6, l7, b7)
[t1, M1] = cantidad_ramas_primarias(OrderArray, l1, b1);
[t2, M2] = num_ramas_rangoSeparacion(branches_height, l2, b2);
primarias = length(find(OrderArray == 1));
[t3, M3] = calidad_distribucion_helicoidal(azimuths, primarias, l3, b3);
[t4, M4] = proyeccion_luz(lai_info, l4, b4);
[t5, M5] = calidad_ramas_finas(ramas_finas, cant_finas);
[t6, M6] = calidad_angles(branches_angle, l6, b6);
[t7, M7] = volumen_podado(volumen_tree, volumen_tree_original, l7, b7);
Valor_Predicado = (M1 * M2 * M3 * M4 * M5 * M6 * M7) ^ (1/7);
Valores_verdad = [t1, M1, t2, M2, t3, M3, t4, M4, t5, M5, t6, M6, t7, M7, Valor_Predicado];
end

function [t1, M1]= cantidad_ramas_primarias(OrderArray, l1, b1)
lambda = l1;% en este caso representa pertenencia de .99
m = .5;
beta = b1;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
t1 = length(find(OrderArray == 1));
sigma = 1 / (1 + exp(-alfa*(lambda - t1)));
M1 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end

function [t2, M2] = num_ramas_rangoSeparacion(branches_height, l2, b2)
lambda = l2;% en este caso representa pertenencia de .5
m = 0;
beta = b2;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
sum_diferencias = 0;
branches_height = sortrows(branches_height);
branches_height = branches_height * 100;
ramas = length(branches_height) - 1;
%'si esta dentro rango se suma 0, si esta fuera de rango se calcula la diferencia'
%'suma de las diferencias, se eleva al cuadrado, de divide entre numero de pares (ramas - 1)'
%'sacar raiz cuadrada'
for idx = 1:ramas
    separacion = branches_height(idx + 1) - branches_height(idx);

    if (35 < separacion)
        diferencia = (separacion - 35);
        sum_diferencias = sum_diferencias + diferencia;
    elseif (separacion < 20)
        diferencia = (20 - separacion);
        sum_diferencias = sum_diferencias + diferencia;
    end
end
sum_diferencias = sum_diferencias / ramas;
t2 = sum_diferencias;
sigma = 1 / (1 + exp(-alfa*(lambda - t2)));
M2 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end

function [t3, M3] = calidad_distribucion_helicoidal(azimuths, t1, l3, b3)
lambda = l3;% en este caso representa pertenencia de .5
m = 0;
beta = b3;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
t3 = 0;
porcionAngulo = 360/t1;
ramas = length(azimuths);
for idx = 1:ramas
    if azimuths(idx) < 0
        azimuths(idx) = azimuths(idx) + 360;
    end
end

azimuths = sortrows(azimuths);
for o = 1: (ramas-1)
    separacionHorizontal = azimuths(o+1) - azimuths(o);
    calidad = (separacionHorizontal - porcionAngulo)^2;
    t3 = t3 + calidad;
end

separacionHorizontal = (360 - azimuths(ramas)) + azimuths(1);
calidad = (separacionHorizontal - porcionAngulo)^2;
t3 = t3 + calidad;
t3 = t3/ramas;
t3 = sqrt(t3);
sigma = 1 / (1 + exp(-alfa*(lambda - t3)));
M3 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end

function [t4, M4] = proyeccion_luz(lai_info, l4, b4)
lambda = l4;% en este caso representa pertenencia de .99
m = .5;
beta = b4;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
%% calcular cross sectional area CSA
% primero obtenemos el diametro de todas las ramas
ramas = lai_info.branch.order > 0;
diametros = lai_info.branch.diameter(ramas) .* 100;
CSAs = pi .* ((diametros ./ 2) .^ 2);

%% calcular branch leaf area
BLA = 0.280 .* (CSAs .^ 1.081);
AFE = sum(BLA);

%% calcular el Projected leaf area
PLA = (lai_info.crownLength ^ 1.532) * exp((lai_info.DBH / lai_info.treeHeight));

%% calcular LAI
t4 = AFE / PLA;
sigma = 1 / (1 + exp(-alfa*(lambda - t4)));
M4 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end

function [t5, M5] = calidad_ramas_finas(ramas_finas, cant_finas)
ramas = length(ramas_finas);
if cant_finas == 0
    lambda = 100;
    beta = 0;
else
    lambda = cant_finas/2;% en este caso representa pertenencia de .5
    beta = cant_finas/3; 
end


m = 1;
M = (m^m)*((1-m)^(1-m));
alfa = -(log(.99) - log(.01)) / (lambda - beta);
ramas_longitud = ramas_finas * 100;
t5 = 0;
for rama = 1: ramas
    if 40 <= ramas_longitud(rama) && ramas_longitud(rama) <= 60
       t5 = t5 + 1;
    end
end
sigma = 1 / (1 + exp(-alfa*(lambda - t5)));
M5 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end

function [t6, M6] = calidad_angles(branches_angles, l6, b6)
ramas = length(branches_angles);
lambda = l6;% en este caso representa pertenencia de .5
m = 0;
beta = ramas * 25;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
sum_diferencias = 0;
for rama = 1: ramas
    if branches_angles(rama) < 45
        diferencia = (45 - branches_angles(rama))^2;
        sum_diferencias = sum_diferencias + diferencia;
    elseif 65 < branches_angles(rama)
        diferencia = (branches_angles(rama) - 65)^2;
        sum_diferencias = sum_diferencias + diferencia;
    end
end
sum_diferencias = sum_diferencias / ramas;
t6 = sqrt(sum_diferencias);
sigma = 1 / (1 + exp(-alfa*(lambda - t6)));
M6 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end


function [t7, M7] = volumen_podado(volumen_tree, volumen_tree_original, l7, b7)
lambda = l7;% en este caso representa pertenencia de .99
m = .5;
beta = b7;
M = (m^m)*((1-m)^(1-m));
alfa = (log(.99) - log(.01)) / (lambda - beta);
t7 = (1 - (volumen_tree / volumen_tree_original)) * 100;
sigma = 1 / (1 + exp(-alfa*(lambda - t7)));
M7 = ((sigma .^ m) .* ((1 - sigma).^(1-m))) / M;
end






