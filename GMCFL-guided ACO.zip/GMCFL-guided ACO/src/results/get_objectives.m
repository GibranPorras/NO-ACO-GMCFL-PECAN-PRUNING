function valor_objetivos = get_objectives(branchData, treeData, volumenInicial, ramas_finas_inicial, NumberBranches, cant_primarias_inicial)
 % caracteristicas = 'treeData', 'branchData'

    rows_primarias = find(branchData.order == 1);
    %rows_finas = find(branchData.order > 1 & branchData.length > 0.6);
    ramas = numel(find(branchData.order > 1));
    branches_height = branchData.height(rows_primarias);
    %branches_finas_length = numel(branchData.length(rows_finas));
    azimuths = branchData.azimuth(rows_primarias);
    branches_angle = branchData.angle(rows_primarias);
    % umbral_poda = 30;

    % calcular las ramas primarias
    t1 = length(rows_primarias);


    %distribucion vertical
    t2 = calculo_calidad_vertical(branches_height);
   

    %distribucion helicoidal
    t3 = calculo_calidad_helicoidal(azimuths);
   

    %Indice LAI
    t4 = calculo_LAI(branchData, treeData.DBHcyl * 100, treeData.CrownLength, treeData.TreeHeight, treeData.CrownAreaAlpha);
    
    
    %Calidad ramas finas
    %t5 = calculo_ramas_finas(branches_finas_length);
    t5 = ramas_finas_inicial - ramas;

    %calidad angulos
    t6 = calculo_angles(branches_angle);

    %calcular volumen podado
    t7 = (1 - (treeData.TotalVolume / volumenInicial)) * 100;
    
    %calcular primarias podadas
    t8 = cant_primarias_inicial - t1;
    

    % aqui comienza la seleccion de las fases
    valor_objetivos = [t1, t2, t3, t4, t5, t6, t7, t8];
end



function t2 = calculo_calidad_vertical(branches_height)

    sum_diferencias = 0;
    branches_height = sortrows(branches_height);
    branches_height = branches_height * 100;
    ramas = length(branches_height) - 1;
    %'si esta dentro rango se suma 0, si esta fuera de rango se calcula la diferencia'
    %'suma de las diferencias, se eleva al cuadrado, de divide entre numero de pares (ramas - 1)'
    %'sacar raiz cuadrada'
    for idx = 1:ramas
        separacion = branches_height(idx + 1) - branches_height(idx);
    
        if (35 < separacion)
            diferencia = (separacion - 35);
            sum_diferencias = sum_diferencias + diferencia;
        elseif (separacion < 20)
            diferencia = (20 - separacion);
            sum_diferencias = sum_diferencias + diferencia;
        end
    end
    sum_diferencias = sum_diferencias / ramas;
    t2 = sum_diferencias;


end


function t3 = calculo_calidad_helicoidal(azimuths)

    t3 = 0;
    porcionAngulo = 360/length(azimuths);
    ramas = length(azimuths);
    for idx = 1:ramas
        if azimuths(idx) < 0
            azimuths(idx) = azimuths(idx) + 360;
        end
    end
    
    azimuths = sortrows(azimuths);
    for o = 1: (ramas-1)
        separacionHorizontal = azimuths(o+1) - azimuths(o);
        calidad = (separacionHorizontal - porcionAngulo)^2;
        t3 = t3 + calidad;
    end
    
    separacionHorizontal = (360 - azimuths(ramas)) + azimuths(1);
    calidad = (separacionHorizontal - porcionAngulo)^2;
    t3 = t3 + calidad;
    t3 = t3/ramas;
    t3 = sqrt(t3);


end



function t4 = calculo_LAI(branchData, DBHcyl, CrownLength, treeHeight, CrownAreaAlpha)

    % calcular cross sectional area CSA
    % primero obtenemos el diametro de todas las ramas
    %ramas = branchData.order > 0;
    %diametros = branchData.diameter(ramas) .* 100;
    %CSAs = pi .* ((diametros ./ 2) .^ 2);

    % calcular branch leaf area
    %BLA = 0.280 .* (CSAs .^ 1.081);
    %AFE = sum(BLA);

    % calcular el Projected leaf area
    PLA = (CrownLength ^ 1.532) * exp((DBHcyl / treeHeight));

    % calcular LAI
    t4 = PLA / CrownAreaAlpha;

end


function t5 = calculo_ramas_finas(finas_length)

    ramas = length(finas_length);
    
    ramas_longitud = finas_length * 100;
    t5 = 0;
    for rama = 1: ramas
        if 40 <= ramas_longitud(rama) && ramas_longitud(rama) <= 60
           t5 = t5 + 1;
        end
    end

end

function t6 = calculo_angles(branches_angles)
    ramas = length(branches_angles);
    sum_diferencias = 0;
    for rama = 1: ramas
        if branches_angles(rama) < 45
            diferencia = (45 - branches_angles(rama))^2;
            sum_diferencias = sum_diferencias + diferencia;
        elseif 65 < branches_angles(rama)
            diferencia = (branches_angles(rama) - 65)^2;
            sum_diferencias = sum_diferencias + diferencia;
        end
    end
    sum_diferencias = sum_diferencias / ramas;
    t6 = sqrt(sum_diferencias);
end

