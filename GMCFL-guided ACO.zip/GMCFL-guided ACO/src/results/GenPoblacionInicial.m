function hormigas = GenPoblacionInicial(cylinder)
% array con todos los cilindros
array_order = cylinder.BranchOrder;

% array solo con cilindros de order mayor a cero
array_order_branch = array_order(array_order ~= 0);
% hormiga con todo inicializado a 0
antSol = zeros(size(array_order));

% calculo para asignar la probabilidad de corte
orders = unique(array_order_branch);
sum_orders = sum(orders);
conteo = zeros(size(orders));
orden_max = max(orders);
for i = 1:length(orders)
    conteo(i) = sum(array_order_branch == orders(i));
end
pesos = double(orders) / sum_orders;
probabilidad = pesos / conteo;

% geracion de hormigas aleatoriamente
a = probabilidad(1) - 0.00020;
b = probabilidad(orden_max) + 0.01;
for i = 1:length(antSol)
    numeroAleatorio = a + (b - a) * rand;
    orden_cilindro = array_order(i);
    if orden_cilindro > 0
        if numeroAleatorio < probabilidad(orden_cilindro)
            antSol(i) = 1;
        end
    end
end
hormigas = antSol';
end

