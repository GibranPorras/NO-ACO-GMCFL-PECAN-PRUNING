function [valor_objetivos, valores_verdad,  Valor_Predicado] = CFL_closeness_model(phase, parametros, branches_data, treeData, volumenInicial, ramas_finas_inicial, NumberBranches, cant_primarias_inicial)
    %% esto necesito para realizar los calculos de los valores
    % caracteristicas = 'treeData', 'branchData'
    % estructura de las metas [Ideal, Indiferente, Nadir]
    % parametros = 'alfa', 'alfa_far','m', 'M', 'lambda', 'nadir', 'ideal', 'prioridad', 'max_prioridad' (en orden de los ojetivos)
    % metas = 'apertura', 'disVertical', 'LAI', 'primarias', 'helicoidal',
    % 'madera', 'finas'

    valor_objetivos = get_objectives(branches_data, treeData, volumenInicial, ramas_finas_inicial, NumberBranches, cant_primarias_inicial);
    if phase == 0
        [valores_verdad,  Valor_Predicado] = phase0(valor_objetivos, parametros);
    elseif phase <= 2
        % aqui se procesa la fase 1 y fase 2
        [valores_verdad,  Valor_Predicado] = phase1_2(valor_objetivos, parametros, phase);
    elseif phase == 3
        % aqui se procesa la fase 3
        [valores_verdad,  Valor_Predicado] = phase3(valor_objetivos, parametros);
    elseif phase == 4
        % aqui se procesa la fase 4
        [valores_verdad,  Valor_Predicado] = phase4(valor_objetivos, parametros);
    elseif phase == 5
        % aqui se procesa la fase 5
        [valores_verdad,  Valor_Predicado] = phase5(valor_objetivos, parametros);
    end


end

function [valores_verdad,  Valor_Predicado] = phase0(valor_objetivos, parametros)
    % 
    valores_verdad = zeros(1, numel(valor_objetivos));
    % 
    % for i = 1 : numel(valor_objetivos)
    % 
    %     t = valor_objetivos(i);
    %     Miu = calcular_miu(parametros.m(i), parametros.lambda(i), parametros.alfa(i), t, parametros.M(i));
    %     valores_verdad(i) = Miu;
    % 
    % end
    % 

    for i = 1 : numel(valor_objetivos)
        t = valor_objetivos(i);
        proportional_difference = get_proportional_difference(t, parametros.ideal(i), parametros.nadir(i));
        if parametros.prioridad(i) == 1
            sigma = calcular_sigma(parametros.lambda(i), parametros.alfa(i), proportional_difference);
        else
            sigma = calcular_sigma(parametros.lambda(i), parametros.alfa_far(i), proportional_difference);
        end
        Miu = 1 - sigma;
        valores_verdad(i) = Miu;
    end


    Valor_Predicado = (prod(valores_verdad)) ^ (1/7);


    
end

function [valores_verdad,  Valor_Predicado] = phase1_2(valor_objetivos, parametros, phase)

    valores_verdad = zeros(1, numel(valor_objetivos));

    for i = 1:numel(valor_objetivos)

        % calculamos el valor de verdad para los objetivos
        t = valor_objetivos(i);
        proportional_difference = get_proportional_difference(t, parametros.ideal(i), parametros.nadir(i));
        Miu = calcular_miu(parametros.m(1), parametros.lambda(i), parametros.alfa(i), proportional_difference, parametros.M(1));

        % x is very close to the aspiration point at the ith coordinate
        % phase 1, si es phase 2 no se eleva al cuadrado
        if phase == 1
            Miu = Miu^2;
        end
        
        valores_verdad(i) = Miu;

    end

    Valor_Predicado = (prod(valores_verdad)) ^ (1/7);
    
end

function [valores_verdad,  Valor_Predicado] = phase3(valor_objetivos, parametros)

    valores_verdad = zeros(1, numel(valor_objetivos));
  

    for i = 1:numel(valor_objetivos)

        % calculamos el valor de verdad para el objetivo 1, primarias
        t = valor_objetivos(i);
        proportional_difference = get_proportional_difference(t, parametros.ideal(i), parametros.nadir(i));

        if parametros.prioridad(i)

            % para los objetivos de prioridad (min)
            Miu = calcular_miu(parametros.m(1), parametros.lambda(i), parametros.alfa(i), proportional_difference, parametros.M(1));

        else

            % para los objetivos sin prioridad (max), es 1 - miu por la
            % negacion 
            Miu = 1 - calcular_miu(parametros.m(2), parametros.lambda(i), parametros.alfa_far(i), proportional_difference, parametros.M(2));

        end

        valores_verdad(i) = Miu;
       
    end

    Valor_Predicado = (prod(valores_verdad)) ^ (1/7);
    

end

function [valores_verdad,  Valor_Predicado] = phase4(valor_objetivos, parametros)

    valores_verdad = zeros(1, numel(valor_objetivos));

    for i = 1:numel(valor_objetivos)

        % calculamos el valor de verdad para el objetivo 1, primarias
        t = valor_objetivos(i);
        proportional_difference = get_proportional_difference(t, parametros.ideal(i), parametros.nadir(i));

        if parametros.prioridad(i)

            % para los objetivos de prioridad (min)
            Miu = calcular_miu(parametros.m(1), parametros.lambda(i), parametros.alfa(i), proportional_difference, parametros.M(1));
            Miu = Miu^2;

        else

            % para los objetivos sin prioridad (max), es 1 - miu por la
            % negacion 
            Miu = calcular_miu(parametros.m(2), parametros.lambda(i), parametros.alfa_far(i), proportional_difference, parametros.M(2));
            Miu = Miu^2;
            Miu = 1 - Miu;
        end

        valores_verdad(i) = Miu;

    end

    Valor_Predicado = (prod(valores_verdad)) ^ (1/7);

end


function [valores_verdad,  Valor_Predicado] = phase5(valor_objetivos, parametros)

    valores_verdad = zeros(1, numel(valor_objetivos));

    for i = 1:numel(valor_objetivos)

        % calculamos el valor de verdad para el objetivo 1, primarias
        t = valor_objetivos(i);
        proportional_difference = get_proportional_difference(t, parametros.ideal(i), parametros.nadir(i));

        if parametros.max_prioridad(i)

            % para los objetivos de prioridad (min)
            Miu = calcular_miu(parametros.m(1), parametros.lambda(i), parametros.alfa(i), proportional_difference, parametros.M(1));
            Miu = Miu^2;

        elseif parametros.prioridad(i)

            Miu = calcular_miu(parametros.m(1), parametros.lambda(i), parametros.alfa(i), proportional_difference, parametros.M(1));

        else

            % para los objetivos sin prioridad (max), es 1 - miu por la
            % negacion 
            Miu = calcular_miu(parametros.m(2), parametros.lambda(i), parametros.alfa_far(i), proportional_difference, parametros.M(2));
            Miu = Miu^2;
            Miu = 1 - Miu;

        end

        valores_verdad(i) = Miu;

    end

    Valor_Predicado = (prod(valores_verdad)) ^ (1/7);

end



function sigma = calcular_sigma(lambda, alfa, t1)

   X = alfa*(t1 - lambda);
   sigma = logsig(X);
    
end


function miu = calcular_miu(m, lambda, alfa, t, M)

    sigma = calcular_sigma(lambda, alfa, t);
    miu = ((sigma ^ m) * ((1 - sigma)^(1-m))) / M;

end

function proportional_difference = get_proportional_difference(t, ideal, nadir)

    proportional_difference = abs((t - ideal) / (nadir - ideal));

end
