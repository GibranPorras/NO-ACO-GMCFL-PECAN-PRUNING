instancia = 'branch_tree_t1_m1_P0.txt';
cil = 'cylinder_tree_t1_m1_P2.txt';
cilindros = readtable(cil);
branches_data = readtable(instancia);
tree_data = readtable('treedata_tree_t1_m1_P0.txt');
orderArray = table2array(branches_data(:,1));
rows_primary = branches_data.order == 1;
rows_finas = branches_data.order > 1;
ramas = branches_data.order > 0;
branches_height = table2array(branches_data(rows_primary, "height_m_"));
azimuths = table2array(branches_data(rows_primary, "azimuth_deg_"));
branches_areas = table2array(branches_data(ramas,"area_m_2_"));
brnaches_volume = table2array(branches_data(ramas,"volume_L_"));
branches_finas = table2array(branches_data(rows_finas,"length_m_"));
branches_angle = table2array(branches_data(rows_primary,"angle_deg_"));
height_tree = table2array(tree_data(4, 2)) * 100;
[t1, t2, t3, t4, t5, t6, rl, vp] = calcular_objetivos(orderArray, branches_height, azimuths, branches_areas, branches_finas, branches_angle, brnaches_volume, height_tree);
disp('Esta es la cantidad de las ramas primarias (t1): ');
disp(t1);
disp('Esta es la calidad de la distribucion vertical (t2): ');
disp(t2);
disp('Calidad de la distribucion helicoidal entre las ramas (t3): ');
disp(t3);
disp('Eficiencia de luz proyectada en el cuadro de plantacion (t4): ');
disp(t4);
disp('Calidad de las ramas finas (t5): ');
disp(t5);
disp('Calidad de angulos respecto al lider (t6): ');
disp(t6);
disp('ramas por debajo de los 200cm (rl): ');
disp(rl);
disp('volumen podado (vp): ');
disp(vp);

disp('Informacion del arbol: ');
disp(tree_data([1, 4, 12, 15, 16, 17, 18, 20], [1, 2]));

disp('Branch Orders: ');
orders = tabulate(cilindros.Var12);
for i = 1:size(orders, 1)
    fprintf('Order %d aparece %d veces\n', orders(i, 1), orders(i, 2));
end